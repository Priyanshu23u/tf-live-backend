package com.travelathon.travel.entity;

public enum EventCategory {
    RACING,
    CONCERT,
    SPORTS,
    STANDUP
}
