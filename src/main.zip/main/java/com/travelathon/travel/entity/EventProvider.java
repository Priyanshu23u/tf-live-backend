package com.travelathon.travel.entity;

public enum EventProvider {
    TICKETMASTER,
    CRICAPI,
    OPENF1,
    THESPORTSDB,
    SPORTMONKS   // 👈 add this
}
