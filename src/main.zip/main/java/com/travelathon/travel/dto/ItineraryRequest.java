package com.travelathon.travel.dto;

public class ItineraryRequest {

    public String eventName;
    public String eventCity;
    public String eventCountry;
    public String eventDate;

    public String originCity;
    public int travelers;
    public int days;

    public int budgetMin;
    public int budgetMax;
}
