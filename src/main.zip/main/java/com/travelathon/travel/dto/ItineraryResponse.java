package com.travelathon.travel.dto;

import com.fasterxml.jackson.databind.JsonNode;

public class ItineraryResponse {

    public JsonNode itinerary; // exact JSON returned by Groq
}
